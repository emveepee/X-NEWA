"""
Copyright (c) 2016 jumpmanjay

A Python interface for the HDHomeRun JSON API
"""
__author__ = "jumpmanjay"
__license__ = "MIT License"
__version__ = "1.0"
